package com.example.myapplicationoperationgame;

public enum OperationType {
    ADDITION,
    SUBSTRACT,
    MULTIPLE,
    DIVIVE;
}
